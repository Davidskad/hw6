
/**
 * Gets the amount if it exists, otherwise returns null
 * @returns {number || null} the amount as a number, or null if empty
 */
function getAmount() {
    // TODO: Get the actual amount! Implement the `getAmount` function such that anytime it is called, it returns the number in the `amount` input element if it exists, otherwise it returns `null`.
    const amountInput = document.getElementById("amount");
    if (!amountInput || amountInput.value === "") {
        return null;
    }
    const value = Number(amountInput.value);
    if (isNaN(value)) {
        return null;
    } else {
        return value;
    }
}

/**
 * Gets the from unit if it is specified, otherwise returns null
 * @returns {string || null} the unit as a string, or null if unspecified
 */
function getFromUnit() {
    // TODO: Get the actual unit!
    const fromUnitSelect = document.getElementById("op-unit-from");
    if (!fromUnitSelect || fromUnitSelect.value === "Please specify a unit") {
        return null;
    }
    return fromUnitSelect.value;
    return "Fl Oz";
}

/**
 * Gets the to unit if it is specified, otherwise returns null
 * @returns {string || null} the unit as a string, or null if unspecified
 */
function getToUnit() {
    // TODO: Get the actual unit!
    const toUnitSelect = document.getElementById("op-unit-to");
    if (!toUnitSelect || toUnitSelect.value === "Please specify a unit") {
        return null;
    }
    return toUnitSelect.value;
    return "Fl Oz";
}

/**
 * This function is called whenever the user presses the "Convert!" button.
 * It should alert the user if any of the fields are null or if the amount is negative.
 * Otherwise, it should call getResult and alert the user of the result.
 * e.g. "2 Pint is equal to 4 Cup"
 */
function convert() {
    // TODO: Call your 3 data grabbing functions, check if they have values,
    //       pass them to getResult, and alert the user of the conversion!
    const amount = getAmount();
    const fromUnit = getFromUnit();
    const toUnit = getToUnit();

    // Check if any fields are null
    if (amount === null || fromUnit === null || toUnit === null) {
        alert("Please complete all fields before continuing!");
        return;
    }

    // Check if amount is negative
    if (amount < 0) {
        alert("Please enter a positive amount!");
        return;
    }

    // Get the conversion result
    const result = getResult(amount, fromUnit, toUnit);

    // Show the result
    alert(`${amount} ${fromUnit} is equal to ${result} ${toUnit}`);
}

/**
 * This function should take the amount, fromUnit, and toUnit, and
 * return the result of the conversion. You should use the
 * getUnitInFlOz function in your calculation.
 * 
 * e.g. arguments of 2, "Pint", "Cup" should return 4
 * 
 * @param {number} amount The amount to convert
 * @param {string} fromUnit The unit we are coming from
 * @param {string} toUnit The unit we are going to
 * @returns {number} the resulting amount, in toUnit units
 */
function getResult(amount, fromUnit, toUnit) {
    // TODO: Return the actual result
    const fromFlOz = getUnitInFlOz(fromUnit);
    const toFlOz = getUnitInFlOz(toUnit);

    // Calculate total fl oz
    const totalFlOz = amount * fromFlOz;

    return totalFlOz / toFlOz;
    return 0;
}

/**
 * Gets the number of fl oz in the given unit
 * @param {string} unit the unit, e.g. "Fl Oz", "Cup", etc.
 * @returns {number || null} the number of fl oz or null if invalid unit
 */
function getUnitInFlOz(unit) {
    if (unit === 'Fl Oz') {
        return 1;
    } else if (unit === 'Cup') {
        return 8;
    } else if (unit === 'Pint') {
        return 16;
    } else if (unit === 'Quart') {
        return 32;
    } else if (unit === 'Gallon') {
        return 128;
    } else {
        return null;
    }
}


